"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { ApiError } from "@/hooks/api";
import { useApproveStoryBible, useSaveStoryBible, useStoryBible } from "@/hooks/useStoryBible";
import type { StoryBibleDraft } from "@/lib/validation/storyBible";

const EMPTY: StoryBibleDraft = { premise: "", worldRules: [], themes: [], boundaries: [], canonFacts: [] };

function lines(value: string): string[] {
  return value.split("\n").map((line) => line.trim()).filter(Boolean);
}

export function StoryBibleEditor({ projectId, readOnly = false }: { projectId: string; readOnly?: boolean }) {
  const query = useStoryBible(projectId);
  const save = useSaveStoryBible(projectId);
  const approve = useApproveStoryBible(projectId);
  const [draft, setDraft] = useState<StoryBibleDraft>(EMPTY);
  const bible = query.data?.bible;

  useEffect(() => {
    if (!bible) return;
    setDraft({
      premise: bible.premise,
      worldRules: bible.worldRules,
      themes: bible.themes,
      boundaries: bible.boundaries,
      canonFacts: bible.canonFacts,
    });
  }, [bible]);

  const pending = save.isPending || approve.isPending;
  const error = save.error ?? approve.error;
  const draftIsSaved = bible && JSON.stringify(draft) === JSON.stringify({
    premise: bible.premise,
    worldRules: bible.worldRules,
    themes: bible.themes,
    boundaries: bible.boundaries,
    canonFacts: bible.canonFacts,
  });

  return (
    <section className="mt-10 border-y border-[#2e2a25] py-6">
      <h2 className="font-display text-3xl">Story Bible</h2>
      <p className="mt-2 max-w-2xl text-sm text-[#a39b8f]">
        Record the premise, world rules, themes, boundaries, and established facts. Only the approved snapshot is supplied to story generation.
      </p>
      {query.isLoading ? <p className="mt-4 text-sm text-[#a39b8f]">Loading Story Bible</p> : null}
      {query.isError ? <p className="mt-4 text-sm text-[#e7b2a8]">The Story Bible could not be loaded.</p> : null}
      {bible ? (
        <div className="mt-5 grid gap-4">
          <label className="grid gap-2 text-sm">
            <span>Premise</span>
            <textarea disabled={readOnly} className="studio-field min-h-24" maxLength={2000} value={draft.premise}
              onChange={(event) => setDraft({ ...draft, premise: event.target.value })} />
          </label>
          <ListField disabled={readOnly} label="World rules" value={draft.worldRules} onChange={(worldRules) => setDraft({ ...draft, worldRules })} />
          <ListField disabled={readOnly} label="Themes" value={draft.themes} onChange={(themes) => setDraft({ ...draft, themes })} />
          <ListField disabled={readOnly} label="Story boundaries" value={draft.boundaries} onChange={(boundaries) => setDraft({ ...draft, boundaries })} />
          <ListField disabled={readOnly} label="Canon facts" value={draft.canonFacts} onChange={(canonFacts) => setDraft({ ...draft, canonFacts })} />
          <p className="text-xs text-[#a39b8f]">
            Approved version: {bible.approvedVersion || "none"}; draft revision {bible.draftRevision}. Saving edits changes only the draft. Approval creates a versioned snapshot.
          </p>
          {error ? <p role="alert" className="text-sm text-[#e7b2a8]">{error instanceof ApiError ? error.message : "The Story Bible could not be updated."}</p> : null}
          <div className="flex flex-wrap gap-3">
            {!readOnly ? <Button variant="quiet" disabled={pending} onClick={() => save.mutate(draft)}>
              {save.isPending ? "Saving" : "Save draft"}
            </Button> : null}
            {!readOnly ? <Button disabled={pending || !draftIsSaved} onClick={() => approve.mutate({
              expectedVersion: bible.approvedVersion,
              expectedDraftRevision: bible.draftRevision,
            })}>
              {approve.isPending ? "Approving" : `Approve version ${bible.approvedVersion + 1}`}
            </Button> : null}
          </div>
          {bible.approvedSnapshot ? (
            <p className="text-xs text-[#a39b8f]">Stories use approved version {bible.approvedSnapshot.version} until another version is approved.</p>
          ) : null}
        </div>
      ) : null}
    </section>
  );
}

function ListField({ label, value, onChange, disabled }: { label: string; value: string[]; onChange: (value: string[]) => void; disabled: boolean }) {
  return (
    <label className="grid gap-2 text-sm">
      <span>{label} <span className="text-xs text-[#a39b8f]">(one item per line)</span></span>
      <textarea disabled={disabled} className="studio-field min-h-20" value={value.join("\n")} maxLength={12000}
        onChange={(event) => onChange(lines(event.target.value))} />
    </label>
  );
}
