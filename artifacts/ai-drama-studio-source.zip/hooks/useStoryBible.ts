"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "@/hooks/api";
import type { StoryBibleDraft, StoryBibleRecord } from "@/lib/validation/storyBible";

const key = (projectId: string) => ["story-bible", projectId] as const;

export function useStoryBible(projectId: string) {
  return useQuery({
    queryKey: key(projectId),
    queryFn: () => api<{ bible: StoryBibleRecord }>(`/api/projects/${projectId}/story-bible`),
  });
}

export function useSaveStoryBible(projectId: string) {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (draft: StoryBibleDraft) => api<{ bible: StoryBibleRecord }>(
      `/api/projects/${projectId}/story-bible`, { method: "PATCH", body: JSON.stringify(draft) }
    ),
    onSuccess: (result) => client.setQueryData(key(projectId), result),
  });
}

export function useApproveStoryBible(projectId: string) {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (input: { expectedVersion: number; expectedDraftRevision: number }) => api<{ bible: StoryBibleRecord }>(
      `/api/projects/${projectId}/story-bible`, {
        method: "POST",
        body: JSON.stringify(input),
      }
    ),
    onSuccess: (result) => client.setQueryData(key(projectId), result),
  });
}
