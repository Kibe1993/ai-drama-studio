import mongoose from "mongoose";
import { connectDB } from "@/lib/db/connect";
import { storyBibleModel } from "@/lib/models/storyBible";
import { projectModel } from "@/lib/models/project";
import { ownedQuery } from "@/lib/repositories/ownership";
import type { StoryBibleDraft, StoryBibleRecord, StoryBibleSnapshot } from "@/lib/validation/storyBible";

type BibleDoc = {
  _id: mongoose.Types.ObjectId;
  clerkUserId: string;
  projectId: mongoose.Types.ObjectId;
  premise?: string;
  worldRules?: string[];
  themes?: string[];
  boundaries?: string[];
  canonFacts?: string[];
  approvedVersion?: number;
  draftRevision?: number;
  approvedSnapshot?: (Omit<StoryBibleSnapshot, "createdAt"> & { createdAt: Date }) | null;
  approvedSnapshots?: (Omit<StoryBibleSnapshot, "createdAt"> & { createdAt: Date })[];
  createdAt: Date;
  updatedAt: Date;
};

function toRecord(doc: BibleDoc): StoryBibleRecord {
  return {
    id: doc._id.toString(),
    clerkUserId: doc.clerkUserId,
    projectId: doc.projectId.toString(),
    premise: doc.premise ?? "",
    worldRules: doc.worldRules ?? [],
    themes: doc.themes ?? [],
    boundaries: doc.boundaries ?? [],
    canonFacts: doc.canonFacts ?? [],
    approvedVersion: doc.approvedVersion ?? 0,
    draftRevision: doc.draftRevision ?? 0,
    approvedSnapshot: doc.approvedSnapshot
      ? { ...doc.approvedSnapshot, createdAt: new Date(doc.approvedSnapshot.createdAt).toISOString() }
      : null,
    approvedSnapshots: (doc.approvedSnapshots ?? []).map((snapshot) => ({
      ...snapshot,
      createdAt: new Date(snapshot.createdAt).toISOString(),
    })),
    createdAt: doc.createdAt.toISOString(),
    updatedAt: doc.updatedAt.toISOString(),
  };
}

async function models() {
  const connection = await connectDB();
  return { Bible: storyBibleModel(connection), Project: projectModel(connection) };
}

export const storyBibleRepository = {
  async findOwned(clerkUserId: string, projectId: string): Promise<StoryBibleRecord | null> {
    const { Bible, Project } = await models();
    if (!(await Project.exists(ownedQuery(clerkUserId, projectId)))) return null;
    const doc = await Bible.findOne({ clerkUserId, projectId }).lean<BibleDoc | null>();
    return doc ? toRecord(doc) : null;
  },

  async findApproved(clerkUserId: string, projectId: string): Promise<StoryBibleSnapshot | null> {
    const bible = await this.findOwned(clerkUserId, projectId);
    return bible?.approvedSnapshot ?? null;
  },

  async findApprovedVersion(clerkUserId: string, projectId: string, version: number): Promise<StoryBibleSnapshot | null> {
    const bible = await this.findOwned(clerkUserId, projectId);
    return bible?.approvedSnapshots.find((snapshot) => snapshot.version === version) ?? null;
  },

  async saveDraft(clerkUserId: string, projectId: string, input: StoryBibleDraft): Promise<StoryBibleRecord | null> {
    const { Bible, Project } = await models();
    if (!(await Project.exists(ownedQuery(clerkUserId, projectId)))) return null;
    const doc = await Bible.findOneAndUpdate(
      { clerkUserId, projectId },
      { $set: input, $setOnInsert: { clerkUserId, projectId }, $inc: { draftRevision: 1 } },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    ).lean<BibleDoc | null>();
    return doc ? toRecord(doc) : null;
  },

  async approve(clerkUserId: string, projectId: string, expectedVersion: number, expectedDraftRevision: number): Promise<StoryBibleRecord | null> {
    const { Bible, Project } = await models();
    if (!(await Project.exists(ownedQuery(clerkUserId, projectId)))) return null;
    const current = await Bible.findOne({ clerkUserId, projectId, approvedVersion: expectedVersion, draftRevision: expectedDraftRevision }).lean<BibleDoc | null>();
    if (!current) return null;
    const state: StoryBibleDraft = {
      premise: current.premise ?? "",
      worldRules: current.worldRules ?? [],
      themes: current.themes ?? [],
      boundaries: current.boundaries ?? [],
      canonFacts: current.canonFacts ?? [],
    };
    const createdAt = new Date();
    const doc = await Bible.findOneAndUpdate(
      { clerkUserId, projectId, approvedVersion: expectedVersion, draftRevision: expectedDraftRevision },
      {
        $set: {
          approvedVersion: expectedVersion + 1,
          approvedSnapshot: { ...state, version: expectedVersion + 1, createdAt },
        },
        $push: { approvedSnapshots: { ...state, version: expectedVersion + 1, createdAt } },
      },
      { new: true }
    ).lean<BibleDoc | null>();
    return doc ? toRecord(doc) : null;
  },
};
