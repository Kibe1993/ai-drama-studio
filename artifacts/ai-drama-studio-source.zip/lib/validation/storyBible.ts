import { z } from "zod";

const entry = z.string().trim().min(1).max(600);

export const storyBibleDraftSchema = z.object({
  premise: z.string().trim().max(2000).default(""),
  worldRules: z.array(entry).max(20).default([]),
  themes: z.array(entry).max(12).default([]),
  boundaries: z.array(entry).max(20).default([]),
  canonFacts: z.array(entry).max(60).default([]),
});

export const storyBibleApprovalSchema = z.object({
  expectedVersion: z.number().int().nonnegative(),
  expectedDraftRevision: z.number().int().nonnegative(),
});

export type StoryBibleDraft = z.infer<typeof storyBibleDraftSchema>;
export type StoryBibleSnapshot = StoryBibleDraft & {
  version: number;
  createdAt: string;
};
export type StoryBibleRecord = StoryBibleDraft & {
  id: string;
  clerkUserId: string;
  projectId: string;
  approvedVersion: number;
  draftRevision: number;
  approvedSnapshot: StoryBibleSnapshot | null;
  approvedSnapshots: StoryBibleSnapshot[];
  createdAt: string;
  updatedAt: string;
};
